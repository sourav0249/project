import React from 'react';
import './App.css';
import Starrating from './Starrating';

function App() {
  return (
    <div className="App">
    <Starrating/>
    </div>
  );
}

export default App;
